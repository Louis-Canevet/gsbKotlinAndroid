package fr.louis.gsbkotlin

class Echantillon(val code: String, var libelle: String, val quantite: String) {
    // Vous pouvez ajouter d'autres méthodes ou fonctionnalités liées à la classe Echantillon ici
}
